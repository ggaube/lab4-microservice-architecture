'use strict';

angular.module('infrastructure', []);
